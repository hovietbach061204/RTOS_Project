#include "software_timer.h"

void Timer_Init(SoftwareTimer *timer, uint32_t timeout_ms) {
    timer->timeout = timeout_ms;
    timer->running = false;
}

void Timer_Start(SoftwareTimer *timer) {
    timer->start_time = millis();
    timer->running = true;
}

bool Timer_IsExpired(SoftwareTimer *timer) {
    if (!timer->running) return false;
    if (millis() - timer->start_time >= timer->timeout) {
        timer->running = false;
        return true;
    }
    return false;
}

void Timer_Reset(SoftwareTimer *timer) {
    timer->start_time = millis();
    timer->running = true;
}
