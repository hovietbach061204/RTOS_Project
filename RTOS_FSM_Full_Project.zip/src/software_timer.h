#ifndef SOFTWARE_TIMER_H
#define SOFTWARE_TIMER_H

#include <Arduino.h>

typedef struct {
    uint32_t start_time;
    uint32_t timeout;
    bool running;
} SoftwareTimer;

void Timer_Init(SoftwareTimer *timer, uint32_t timeout_ms);
void Timer_Start(SoftwareTimer *timer);
bool Timer_IsExpired(SoftwareTimer *timer);
void Timer_Reset(SoftwareTimer *timer);

#endif // SOFTWARE_TIMER_H
