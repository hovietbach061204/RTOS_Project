#ifndef BLINKY_TASK_H
#define BLINKY_TASK_H

void blinky_task(void);

#endif
