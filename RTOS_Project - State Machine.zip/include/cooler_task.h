#ifndef COOLER_TASK_H
#define COOLER_TASK_H

void setup_cooler_leds(void);
void cooler_task(void);

#endif
