#ifndef HEATER_TASK_H
#define HEATER_TASK_H

void setup_heater_leds(void);
void heater_task(void);

#endif
