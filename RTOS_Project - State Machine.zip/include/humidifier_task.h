#ifndef HUMIDIFIER_TASK_H
#define HUMIDIFIER_TASK_H

void setup_humidifier_leds(void);
void humidifier_task(void);

#endif
