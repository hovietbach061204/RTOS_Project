#include "blinky_task.h"
#include <Arduino.h>

void blinky_task() {
    static bool led_state = false;
    led_state = !led_state;
    digitalWrite(LED_BUILTIN, led_state ? LOW : HIGH);  // LOW = ON
}
