#include "cooler_task.h"
#include "defines.h"
#include "sensor_task.h"
#include "software_timer.h"
#include <Arduino.h>

typedef enum {
    COOLER_IDLE,
    COOLER_ACTIVE
} CoolerState;

static CoolerState cooler_state = COOLER_IDLE;

void setup_cooler_leds() {
    pinMode(COOLER_LED1, OUTPUT);
    pinMode(COOLER_LED2, OUTPUT);
    digitalWrite(COOLER_LED1, LOW);
    digitalWrite(COOLER_LED2, LOW);
}

void cooler_task() {
  
    switch(cooler_state) {   
        case COOLER_IDLE:
            if (temperature > COOLER_THRESHOLD) {
                digitalWrite(COOLER_LED1, HIGH);
                digitalWrite(COOLER_LED2, LOW);
                Timer_Set(0, 500); // 5s -> 500 ticks of 10ms
                cooler_state = COOLER_ACTIVE;
            }
            break;

        case COOLER_ACTIVE:
            if (Timer_IsExpired(0)) {
                digitalWrite(COOLER_LED1, LOW);
                digitalWrite(COOLER_LED2, LOW);
                cooler_state = COOLER_IDLE;
            }
            break;
    }
}
