#include "heater_task.h"
#include "defines.h"
#include "sensor_task.h"
#include <Arduino.h>

void setup_heater_leds() {
    pinMode(HEATER_LED1, OUTPUT);
    pinMode(HEATER_LED2, OUTPUT);
    digitalWrite(HEATER_LED1, LOW);
    digitalWrite(HEATER_LED2, LOW);
}

void heater_task() {
    if (temperature >= HEATER_WARNING_THRESHOLD) {
        // Safe (Green): Both LEDs ON
         digitalWrite(HEATER_LED1, HIGH); //Green
        digitalWrite(HEATER_LED2, LOW);
    } else if (temperature >= HEATER_DANGER_THRESHOLD) {
        // Warning (Orange): One LED ON, one OFF
        digitalWrite(HEATER_LED1, LOW);
        digitalWrite(HEATER_LED2, HIGH);
    } else {
        // Danger (Red): Both LEDs OFF
        digitalWrite(HEATER_LED1, HIGH); // Red
        digitalWrite(HEATER_LED2, HIGH);
    }
}
