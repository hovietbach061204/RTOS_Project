#include "humidifier_task.h"
#include "defines.h"
#include "sensor_task.h"
#include "software_timer.h"
#include <Arduino.h>

typedef enum {
    HUMIDIFIER_IDLE,
    HUMIDIFIER_GREEN,
    HUMIDIFIER_YELLOW,
    HUMIDIFIER_RED
} HumidifierState;

static HumidifierState humidifier_state = HUMIDIFIER_IDLE;

void setup_humidifier_leds() {
    pinMode(HUMIDIFIER_LED1, OUTPUT);
    pinMode(HUMIDIFIER_LED2, OUTPUT);
    digitalWrite(HUMIDIFIER_LED1, LOW);
    digitalWrite(HUMIDIFIER_LED2, LOW);
}

void humidifier_task() {
    switch (humidifier_state) {
        case HUMIDIFIER_IDLE:
            if (humidity < HUMIDIFIER_THRESHOLD) {
                digitalWrite(HUMIDIFIER_LED1, HIGH);
                digitalWrite(HUMIDIFIER_LED2, HIGH);
                Timer_Set(TIMER_HUMIDIFIER_GREEN, 500); // 5s
                humidifier_state = HUMIDIFIER_GREEN;
            }
            break;

        case HUMIDIFIER_GREEN:
            if (Timer_IsExpired(TIMER_HUMIDIFIER_GREEN)) {
                digitalWrite(HUMIDIFIER_LED1, HIGH);
                digitalWrite(HUMIDIFIER_LED2, LOW);
                Timer_Set(TIMER_HUMIDIFIER_YELLOW, 300); // 3s
                humidifier_state = HUMIDIFIER_YELLOW;
            }
            break;

        case HUMIDIFIER_YELLOW:
            if (Timer_IsExpired(TIMER_HUMIDIFIER_YELLOW)) {
                digitalWrite(HUMIDIFIER_LED1, LOW);
                digitalWrite(HUMIDIFIER_LED2, HIGH);
                Timer_Set(TIMER_HUMIDIFIER_RED, 200); // 2s
                humidifier_state = HUMIDIFIER_RED;
            }
            break;

        case HUMIDIFIER_RED:
            if (Timer_IsExpired(TIMER_HUMIDIFIER_RED)) {
                if (humidity < HUMIDIFIER_THRESHOLD) {
                    digitalWrite(HUMIDIFIER_LED1, HIGH);
                    digitalWrite(HUMIDIFIER_LED2, HIGH);
                    Timer_Set(TIMER_HUMIDIFIER_GREEN, 500);
                    humidifier_state = HUMIDIFIER_GREEN;
                } else {
                    digitalWrite(HUMIDIFIER_LED1, LOW);
                    digitalWrite(HUMIDIFIER_LED2, LOW);
                    humidifier_state = HUMIDIFIER_IDLE;
                }
            }
            break;
    }
}
