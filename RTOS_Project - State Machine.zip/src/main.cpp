#include <Arduino.h>
#include "scheduler.h"

#include "blinky_task.h"
#include "sensor_task.h"
#include "heater_task.h"
#include "cooler_task.h"
#include "humidifier_task.h"

void setup() {
    Serial.begin(115200);

    Wire.begin(GPIO_NUM_11, GPIO_NUM_12); // Red port on YoluUNO
    dht20.begin();

    pinMode(LED_BUILTIN, OUTPUT);

    // Setup all device LEDs
    setup_cooler_leds();
    setup_heater_leds();
    setup_humidifier_leds();

    SCH_Init();

    // Add all tasks
    SCH_Add_Task(blinky_task, 0, 100);        // 1s = 100 ticks
    SCH_Add_Task(sensor_task, 0, 500);         // 5s = 500 ticks
    SCH_Add_Task(heater_task, 0, 100);          // 1s
    SCH_Add_Task(cooler_task, 0, 100);          // 1s
    SCH_Add_Task(humidifier_task, 0, 1);        // 10ms
}

void loop() {
    SCH_Dispatch_Tasks();
}
