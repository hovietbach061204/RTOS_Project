#include "sensor_task.h"
#include <Arduino.h>
#include "defines.h"
#include <DHT20.h>

DHT20 dht20;


float temperature = 0.0;
float humidity = 0.0;

void sensor_task() {
    dht20.read();

    if (dht20.read() == 0) {
        float temp = dht20.getTemperature();
        float hum = dht20.getHumidity();
    
        if (temp > -40.0 && temp < 85.0 && hum >= 0.0 && hum <= 100.0) {
            // ✅ Sensor data is valid
            digitalWrite(HEATER_LED1, HIGH); // Green LED
            digitalWrite(HEATER_LED2, LOW);
        } else {
            // ❌ Data is invalid
            digitalWrite(HEATER_LED1, LOW);
            digitalWrite(HEATER_LED2, HIGH); // Orange LED
        }
    } else {
        // ❌ Communication failed
        digitalWrite(LED_BUILTIN, LOW); // Red onboard LED ON
    }
    
}
