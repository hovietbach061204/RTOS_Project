#ifndef SOFTWARE_TIMER_H
#define SOFTWARE_TIMER_H

void Timer_Set(int index, int value);
int Timer_IsExpired(int index);
void Timer_Run(void);

#endif
